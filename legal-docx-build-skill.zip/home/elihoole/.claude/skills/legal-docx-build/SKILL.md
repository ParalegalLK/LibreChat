---
name: legal-docx-build
description: Build a formatted Word DOCX from one or more Markdown drafts of a legal document (writ petition, submission, affidavit, legal brief, application). Produces continuous numbered paragraphs, (a)(b)(c) sub-paragraphs, (i)(ii)(iii) nested lists, real Word auto-numbering, page breaks between sections, and a table of contents with Roman-numeral front matter and Arabic body page numbers. Use when the user wants to compile/convert/render Markdown into a final court-ready or legal Word document, or to combine multiple Markdown parts into one continuously numbered DOCX.
---

# Legal DOCX Build

Converts Markdown legal drafts into a court-ready Word `.docx` via a fixed Pandoc pipeline with post-processors. The whole build is one script — do not re-implement the steps inline.

## Usage

```bash
bash ~/.claude/skills/legal-docx-build/build-legal-docx.sh <source.md> [source2.md ...] <output.docx>
```

The **last** argument is always the output path; everything before it is input Markdown (concatenated in order). The output directory is created if missing.

Examples:

```bash
# Single draft
bash ~/.claude/skills/legal-docx-build/build-legal-docx.sh draft.md outputs/petition.docx

# Combine parts into one continuously numbered document
bash ~/.claude/skills/legal-docx-build/build-legal-docx.sh part1.md part2.md outputs/combined.docx
```

Requires `pandoc` and `uv` on PATH (the script runs the Python helpers via `uv run --with python-docx`). No need to install python-docx separately.

## What the build does (in order)

1. **Continuous numbering** — every `N.` paragraph is renumbered sequentially across all input files (part 2 continues from where part 1 ended). All-caps headings are converted to title case.
2. **Bullets → sub-paragraphs** — Markdown `-`/`*` bullets become `(a)`, `(b)`, `(c)` … with legal punctuation (`;` between items, `; and` before the last, `.` to close).
3. **Page breaks** — a page break is inserted before each `#` heading after the first.
4. **Nested numbered lists → (i)(ii)(iii)** — indented numbered sub-lists are inlined as Roman-numeral runs.
5. **Strip LaTeX** — raw `{=latex}` blocks are removed.
6. **Pandoc → DOCX** — using `utils/reference.docx` for styles and `filters/legal-docx-format.lua`; adds a numbered TOC (depth 3).
7. **Word auto-numbering** — plain-text `N.` and `(a)` prefixes are replaced with real Word `<w:numPr>` auto-numbering, and headings get multilevel `1` / `1.1` numbering.
8. **TOC page numbering** — front matter (TOC) gets lower-Roman page numbers; the body restarts at Arabic page 1.

## Environment toggles

Set these before the command to vary output:

- `LEGAL_NO_TOC=1` — skip the table of contents (also skips step 8).
- `LEGAL_NO_PAGEBREAKS=1` — do not insert page breaks between `#` sections (single-flow documents).

```bash
LEGAL_NO_TOC=1 bash ~/.claude/skills/legal-docx-build/build-legal-docx.sh affidavit.md outputs/affidavit.docx
```

## Input Markdown conventions

- Number top-level paragraphs as `1.`, `2.`, … in each source file; they are renumbered automatically, so each file can safely restart at `1.`.
- Use `#` for top-level sections (these page-break and get TOC entries), `##` / `###` for sub-sections.
- Use `-`/`*` bullets for items that should render as `(a)(b)(c)` sub-paragraphs.
- Block quotes render italic; `###` headings are left unnumbered by design.

## Customizing styles

Fonts, margins, and paragraph styles live in `utils/reference.docx`. To change them, open that file in Word, edit the named styles (`First Paragraph`, `Body Text`, `Heading 1`, `Heading 2`, `Title`, TOC styles), and save. The numbering/indent geometry for auto-numbered paragraphs is set in `utils/apply_legal_numbering.py` (`_make_level` calls).
