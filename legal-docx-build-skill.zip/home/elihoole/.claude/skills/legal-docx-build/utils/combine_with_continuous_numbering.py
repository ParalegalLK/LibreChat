#!/usr/bin/env python3
"""
Combines multiple markdown files with continuous paragraph numbering.
Each top-level section starts on a new page, and paragraphs are renumbered
continuously across all files (e.g., if file 1 ends at para 31, file 2 starts at 32).
"""

import re
import sys
from pathlib import Path


def to_title_case(text: str) -> str:
    """
    Convert all-caps text to title case, preserving acronyms and special cases.
    """
    # List of words that should remain uppercase (acronyms, etc.)
    preserve_upper = {'PIL', 'GSMB', 'ASHA', 'SLCC', 'EIA', 'IML', 'CA', 'CEA', 'BOI'}

    # Small words that should be lowercase (unless first or last word)
    small_words = {'a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 'in', 'of', 'on', 'or', 'the', 'to', 'vs'}

    words = text.split()
    result = []

    for i, word in enumerate(words):
        # Remove leading/trailing punctuation for checking
        stripped = word.strip('–—-()[]{}.,;:!?')

        if stripped in preserve_upper:
            # Keep acronyms in uppercase
            result.append(word)
        elif i == 0 or i == len(words) - 1:
            # First and last words are always capitalized
            result.append(word.capitalize())
        elif stripped.lower() in small_words:
            # Small words are lowercase (unless first/last)
            result.append(word.lower())
        else:
            # Everything else is title case
            result.append(word.capitalize())

    return ' '.join(result)


def renumber_paragraphs(content: str, start_num: int) -> tuple[str, int]:
    """
    Renumber paragraphs in markdown content, starting from start_num.
    Returns (renumbered_content, next_number).

    Matches patterns like:
    - "1. Some text"
    - "12. Some text"

    at the beginning of lines.

    Also converts all-caps headings to title case.
    """
    lines = content.split('\n')
    output_lines = []
    current_num = start_num

    for line in lines:
        # Convert all-caps headings to title case
        heading_match = re.match(r'^(#{1,6})\s+(.+)$', line)
        if heading_match:
            heading_level = heading_match.group(1)
            heading_text = heading_match.group(2)
            # Only convert if it's mostly uppercase
            if heading_text.isupper() or sum(c.isupper() for c in heading_text if c.isalpha()) > len([c for c in heading_text if c.isalpha()]) * 0.7:
                heading_text = to_title_case(heading_text)
            output_lines.append(f"{heading_level} {heading_text}")
            continue

        # Match paragraph numbers at start of line: "1. ", "123. ", etc.
        match = re.match(r'^(\d+)\.\s+(.*)$', line)
        if match:
            # Replace with continuous numbering
            rest_of_line = match.group(2)
            output_lines.append(f"{current_num}. {rest_of_line}")
            current_num += 1
        else:
            # Keep line as-is
            output_lines.append(line)

    return '\n'.join(output_lines), current_num


def main():
    if len(sys.argv) < 3:
        print("Usage: combine_with_continuous_numbering.py output_file input_file1 [input_file2 ...]")
        sys.exit(1)

    output_file = Path(sys.argv[1])
    input_files = [Path(f) for f in sys.argv[2:]]

    # Verify all input files exist
    for f in input_files:
        if not f.exists():
            print(f"Error: file not found: {f}")
            sys.exit(1)

    combined_content = []
    current_para_num = 1

    for i, input_file in enumerate(input_files):
        print(f"Processing {input_file.name}...", file=sys.stderr)

        content = input_file.read_text(encoding='utf-8')

        # Renumber paragraphs in this file
        renumbered, next_num = renumber_paragraphs(content, current_para_num)

        # Add to combined content
        if i > 0:
            # Add page break before each new file (except the first)
            # Check if this file starts with a heading
            if renumbered.strip().startswith('#'):
                # Page break will be added by LaTeX before section headings
                combined_content.append(renumbered)
            else:
                # Add explicit page break
                combined_content.append('\\newpage\n\n' + renumbered)
        else:
            combined_content.append(renumbered)

        # Update paragraph counter for next file
        current_para_num = next_num

        para_count = next_num - current_para_num
        if para_count > 0:
            print(f"  Renumbered {para_count} paragraphs", file=sys.stderr)

    # Write combined output
    output_file.write_text('\n\n'.join(combined_content), encoding='utf-8')
    print(f"\n✓ Combined {len(input_files)} files into {output_file}", file=sys.stderr)
    print(f"  Total paragraphs: {current_para_num - 1}", file=sys.stderr)


if __name__ == '__main__':
    main()